<?php

// Display header top bar
function corporateplus_header_top_show(){
	global $corporateplus_opt;
	return $corporateplus_opt['show_header_top_bar'];
}

// Phone number
function corporateplus_top_bar_phone(){
	global $corporateplus_opt;
	return $corporateplus_opt['top_bar_phone'];
}

// Email Address
function corporateplus_top_bar_email(){
	global $corporateplus_opt;
	return $corporateplus_opt['top_bar_email'];
}

// User Address
function corporateplus_top_bar_time(){
	global $corporateplus_opt;
	return $corporateplus_opt['top_bar_time'];
}

// Topbar Social link
function corporateplus_social_icons(){
	global $corporateplus_opt;
	if(isset($corporateplus_opt['topbar_social_icons'])) {?>							
		<?php echo '<ul class="social-icons">';
			foreach($corporateplus_opt['topbar_social_icons'] as $key=>$value ) {
				if($value!=''){
					if($key=='vimeo'){
						echo '<li><a class="'.esc_attr($key).' social-icon" href="'.esc_url($value).'" title="'.ucwords(esc_attr($key)).'" target="_blank"><i class="fa fa-vimeo"></i></a></li>';
					} else {
						echo '<li><a class="'.esc_attr($key).' social-icon" href="'.esc_url($value).'" title="'.ucwords(esc_attr($key)).'" target="_blank"><i class="fa fa-'.esc_attr($key).'"></i></a></li>';
					}
				}
			}
			echo '</ul>';
		?>							
	<?php };
}

// Corporate Plus hearder top
function corporateplus_header_top(){
	if( corporateplus_header_top_show() == true ) :  ?>
		<!-- tiny header starts -->
		<div class="tiny_header">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="contact_email">
							<ul>
								<li><span>
									<?php global $corporateplus_opt; 
										if( ! empty ($corporateplus_opt['top_bar_email'])) { ?>
											<i class="fa fa-envelope"></i>
											<?php } 
									?>
									</span>
									<a href="mailto:<?php esc_attr(corporateplus_top_bar_email()); ?>">
										<?php echo esc_html(corporateplus_top_bar_email()); ?>
									</a>
								</li>
								<li><span>
									<?php global $corporateplus_opt; 
										if( ! empty ($corporateplus_opt['top_bar_phone'])) { ?>
											<i class="fa fa-phone"></i>
											<?php } 
									?>
									</span>
									<a href="tel:<?php esc_attr(corporateplus_top_bar_phone()); ?>">
										<?php echo esc_html(corporateplus_top_bar_phone()); ?>
									</a>
								</li>
							</ul>
						</div>
						<div class="social_icons">
							<ul>
								<li><span>
									<?php global $corporateplus_opt; 
										if( ! empty ($corporateplus_opt['top_bar_time'])) { ?>
											<i class="fa fa-solid fa-calendar"></i>
											<?php } 
									?>
									</span>
									<a>
										<?php echo esc_html(corporateplus_top_bar_time()); ?>
									</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- tiny header ends -->
	<?php endif;
} 

// display logo
function corporateplus_logo(){
	global $corporateplus_opt;
	if(is_ssl()){
		$corporateplus_opt['logo_main']['url'] = str_replace('http:', 'https:', $corporateplus_opt['logo_main']['url']);
	}
	
	if( !empty($corporateplus_opt['logo_main']['url']) ){ ?>
			<a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
				<img class="svg" src="<?php echo esc_url($corporateplus_opt['logo_main']['url']); ?>" alt="<?php esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" />
			</a>
		<?php
		} else { ?>
			<h1 class="navbar-blog-info"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
			<?php
		} ?>
	<?php
}

// Main Menu
function corporateplus_main_menu(){
	wp_nav_menu( array(
		'theme_location'    => 'menu-1',
		'container' 	=> '',
		'fallback_cb'   => 'corporateplus_menu_cb',
		'items_wrap' 	=> '<ul class="nav navbar-nav">%3$s</ul>' 
	));
}

// Main Menu Callback 
function corporateplus_menu_cb (){
	echo '<ul class="nav navbar-nav">';
	echo '<li><a href="' . admin_url( 'nav-menus.php' ) . '">'. esc_html('Add a menu','').'</a></li>';
	echo '</ul>';
}

// blog read more
function corporateplus_blog_read_more(){
	global $corporateplus_opt;
	if(isset($corporateplus_opt)){ 
		echo esc_html($corporateplus_opt['readmore_text']); 
	} 
	else { 
		esc_html_e('Read More ...', 'corporateplus');
	}
}

// display pages breadcrumb
function corporateplus_pages_breadcrumb(){
	global $corporateplus_opt;
	$condition = true;
	
	if ( class_exists( 'ReduxFrameworkPlugin' ) ){
		$condition = $corporateplus_opt['breadcrumb_on_off'];
	}
	
	if($condition){ ?>
	<!--================================
		2.START BREADCRUMB AREA CSS
	=================================-->
	<section class="breadcrumb pages_bdcmb">
	  <div class="container">
		<div class="row">
		  <div class="col-md-12">
			<div class="breadcrumb_title_wrapper">
			  <div class="page_title">
				<h1><?php the_title();?></h1>
			  </div>

			  <div class="bread_crumb">
				<?php if(function_exists('bcn_display')) {
					bcn_display();
				}?>
			  </div>

			</div>
		  </div>
		</div>
	  </div>
	</section>
	<!--================================
		2.END BREADCRUMB AREA CSS
	=================================-->
	<?php }
}

// display blog breadcrumb
function corporateplus_blogs_breadcrumb(){
	global $corporateplus_opt;
	$condition = true;
	if ( class_exists( 'ReduxFrameworkPlugin' ) ){
		$condition = $corporateplus_opt['breadcrumb_on_off_blog'];
	}
	if($condition){ ?>
	<!--================================
		2.START BREADCRUMB AREA CSS
	=================================-->
	<section class="breadcrumb blog-bdcmb">
	  <div class="container">
		<div class="row">
		  <div class="col-md-12">
			<div class="breadcrumb_title_wrapper">
			  <div class="page_title">
				<h1><?php esc_html_e('Blog' , 'corporateplus');?></h1>
			  </div>
			  <ul class="bread_crumb">
				<li><a href="<?php echo esc_url( home_url('/') ); ?>"><?php esc_html_e('Home' , 'corporateplus');?></a></li>
				<li class="bread_active"><?php esc_html_e('Blog' , 'corporateplus');?></li>
			  </ul>
			</div>
		  </div>
		</div>
	  </div>
	</section>
	<!--================================
		2.END BREADCRUMB AREA CSS
	=================================-->
	<?php }
}

// display single blog breadcrumb
function corporateplus_single_blog_breadcrumb(){
	global $corporateplus_opt;
	$condition = true;
	if ( class_exists( 'ReduxFrameworkPlugin' ) ){
		$condition = $corporateplus_opt['breadcrumb_on_off_blog'];
	}
	if($condition){ ?>
	<!--================================
		2.START BREADCRUMB AREA CSS
	=================================-->
	<section class="breadcrumb blog-bdcmb">
	  <div class="container">
		<div class="row">
		  <div class="col-md-12">
			<div class="breadcrumb_title_wrapper">
			  <div class="page_title">
				<h1><?php esc_html_e('Blog' , 'corporateplus');?></h1>
			  </div>
			  <ul class="bread_crumb">
				<li><a href="<?php echo esc_url( home_url('/') ); ?>"><?php esc_html_e('Home' , 'corporateplus');?></a></li>
				<li class="bread_active"><?php esc_html_e('Blog' , 'corporateplus');?></li>
			  </ul>
			</div>
		  </div>
		</div>
	  </div>
	</section>
	<!--================================
		2.END BREADCRUMB AREA CSS
	=================================-->
	<?php }
}

// display archive breadcrumb
function corporateplus_archive_breadcrumb(){
	global $corporateplus_opt;
	$condition = true;
	if ( class_exists( 'ReduxFrameworkPlugin' ) ){
		$condition = $corporateplus_opt['breadcrumb_on_off_blog'];
	}
	if($condition){ ?>
	<!--================================
		2.START BREADCRUMB AREA CSS
	=================================-->
	<section class="breadcrumb blog-bdcmb">
	  <div class="container">
		<div class="row">
		  <div class="col-md-12">
			<div class="breadcrumb_title_wrapper">
			  <div class="page_title">
			    <?php the_archive_title( '<h1>', '</h1>' ); ?>
			  </div>
			  <ul class="bread_crumb">
				<li><a href="<?php echo esc_url( home_url('/') ); ?>"><?php esc_html_e('Home' , 'corporateplus');?></a></li>
				<li class="bread_active"><?php the_archive_title(); ?></li>
			  </ul>
			</div>
		  </div>
		</div>
	  </div>
	</section>
	<!--================================
		2.END BREADCRUMB AREA CSS
	=================================-->
	<?php }
}

// display search breadcrumb
function corporateplus_search_breadcrumb(){
	global $corporateplus_opt;
	$condition = true;
	if ( class_exists( 'ReduxFrameworkPlugin' ) ){
		$condition = $corporateplus_opt['breadcrumb_on_off_blog'];
	}
	if($condition){ ?>
	<!--================================
		2.START BREADCRUMB AREA CSS
	=================================-->
	<section class="breadcrumb blog-bdcmb">
	  <div class="container">
		<div class="row">
		  <div class="col-md-12">
			<div class="breadcrumb_title_wrapper">
			  <div class="page_title">
				<h1><?php printf( esc_html__( 'Search Results for: %s', 'corporateplus' ), '<span>' . get_search_query() . '</span>' ); ?></h1>
			  </div>
			  <ul class="bread_crumb">
				<li><a href="<?php echo esc_url( home_url('/') ); ?>"><?php esc_html_e('Home' , 'corporateplus');?></a></li>
				<li class="bread_active">
					<?php if ( have_posts() ) :
						printf( '<span>' . get_search_query() . '</span>' );
					else :
						esc_html_e( 'Nothing Found', 'corporateplus' );
					endif; ?>
				</li>
			  </ul>
			</div>
		  </div>
		</div>
	  </div>
	</section>
	<!--================================
		2.END BREADCRUMB AREA CSS
	=================================-->
	<?php }
}

// display error page breadcrumb
function corporateplus_error_page_breadcrumb(){
	global $corporateplus_opt;
	$condition = true;
	if ( class_exists( 'ReduxFrameworkPlugin' ) ){
		$condition = $corporateplus_opt['breadcrumb_on_off_error'];
	}
	if($condition){ ?>	
	<!--================================
		2.START BREADCRUMB AREA CSS
	=================================-->
	<section class="breadcrumb error-page">
	  <div class="container">
		<div class="row">
		  <div class="col-md-12">
			<div class="breadcrumb_title_wrapper">
			  <div class="page_title">
				<h1><?php the_title(); ?></h1>
			  </div>
			  <ul class="bread_crumb">
				<li><a href="<?php echo esc_url( home_url('/') ); ?>"><?php esc_html_e('Home' , 'corporateplus');?></a></li>
				<li class="bread_active"><?php the_title(); ?></li>
			  </ul>
			</div>
		  </div>
		</div>
	  </div>
	</section>
	<!--================================
		2.END BREADCRUMB AREA CSS
	=================================-->
	<?php }
}

// Contact copyright text
function corporateplus_copyright(){
	global $corporateplus_opt;
	if( isset($corporateplus_opt['copyright']) && $corporateplus_opt['copyright']!='' ) {
		echo wp_kses($corporateplus_opt['copyright'], array(
			'a' => array(
				'href' => array(),
				'title' => array()
			),
			'br' => array(),
			'em' => array(),
			'strong' => array(),
		));
	} else {
		echo esc_html__('Copyright &copy; 2022 ' , 'corporateplus'). " <a href='".esc_url('https://www.vrinsofts.com/')."' target='_blank'>".esc_html__('corporateplus' , 'corporateplus')."</a> ".esc_html__('All Rights Reserved by Vrinsoft.' , 'corporateplus');

	};
}


// 404 error page title
function corporateplus_not_found_title() {
	global $corporateplus_opt;
	if ($corporateplus_opt['notfound_title']){
		echo esc_html( $corporateplus_opt['notfound_title'] );
	}
	else {
		echo esc_html('Oops! The page doesn\'t seem to be exists.', 'corporateplus');
	}
}

// 404 error page error massage
function corporateplus_not_found_content() {
	global $corporateplus_opt;
	if ($corporateplus_opt['notfound_content']){
		echo esc_html( $corporateplus_opt['notfound_content'] );
	}
}

// footer sidebar function
function corporateplus_footer_sidebar(){
	if ( is_active_sidebar( 'footer-sidebar' ) ) : ?>
		<div class="footer_wrapper">
			<div class="container">
				<div class="row">
					<?php dynamic_sidebar( 'footer-sidebar' ); ?>
				</div>
			</div>
		</div>
	<?php endif;
}


//Add google map API
function corporateplus_googlemap_api(){
	global $corporateplus_opt;
	//Add google map API
	$google_map_js_url = 'https://maps.googleapis.com/maps/api/js?key=' . $corporateplus_opt['map_apy_key'];
	return esc_url_raw($google_map_js_url);
}

//For enqueue google map script
function corporateplus_googlemap_api_enqueue(){
	wp_enqueue_script( 'google-map', corporateplus_googlemap_api(), array(), null );
}

// Google map 
function corporateplus_googlemap (){ 
	global $corporateplus_opt; 
	$map_desc = str_replace(array("\r\n", "\r", "\n"), "<br />", $corporateplus_opt['map_desc']);
	$map_desc = addslashes($map_desc);
	ob_start(); 
?>
		<script type="text/javascript">
        var myCenter=new google.maps.LatLng(<?php if(isset($corporateplus_opt['map_lat'])) { echo esc_js($corporateplus_opt['map_lat']); } else { echo '40.76732'; } ?>, <?php if(isset($corporateplus_opt['map_long'])) { echo esc_js($corporateplus_opt['map_long']); } else { echo '-74.20487'; } ?>);
            function initialize()
            {
            var mapProp = {
              center:myCenter,
              zoom:<?php if(isset($corporateplus_opt['map_zoom'])) { echo esc_js($corporateplus_opt['map_zoom']); } else { echo 14; } ?>,
              scrollwheel:<?php if($corporateplus_opt['map_scrollwheel'] == 0 ) { echo 'false'; } else { echo 'true'; } ?>,
              mapTypeId:google.maps.MapTypeId.ROADMAP,
                styles: [{"featureType":"water","elementType":"geometry","stylers":[{"color":"<?php echo esc_js($corporateplus_opt['map_color']);?>"},{"lightness":17}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":20}]},{"featureType":"road.highway","elementType":"geometry.fill","stylers":[{"color":"#ffffff"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#ffffff"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":16}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":21}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"color":"#dedede"},{"lightness":21}]},{"elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"lightness":16}]},{"elementType":"labels.text.fill","stylers":[{"saturation":36},{"color":"#333333"},{"lightness":40}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#f2f2f2"},{"lightness":19}]},{"featureType":"administrative","elementType":"geometry.fill","stylers":[{"color":"#fefefe"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#fefefe"},{"lightness":17},{"weight":1.2}]}]
              };

            var map=new google.maps.Map(document.getElementById("google_map"),mapProp);

            var marker=new google.maps.Marker({
              position:myCenter,
              animation:google.maps.Animation.BOUNCE,
              icon:'<?php if( isset($corporateplus_opt['map_marker']['url']) && $corporateplus_opt['map_marker']['url']!='') :
					echo esc_js($corporateplus_opt['map_marker']['url']);
				else :
					esc_url(get_template_directory_uri() . '/images/map-marker.png');
				endif; ?>'
            });
			var infowindow = new google.maps.InfoWindow({
				content: "<?php echo wp_kses($map_desc, array(
							'a' => array(
								'href' => array(),
								'title' => array()
							),
							'i' => array(
								'class' => array()
							),
							'img' => array(
								'src' => array(),
								'alt' => array()
							),
							'br' => array(),
							'em' => array(),
							'strong' => array(),
							'p' => array(),
						)); ?>"
			});
			infowindow.open(map,marker);

            marker.setMap(map);
            }
			var mapContainer = jQuery('#google_map');
			if(mapContainer.length){
				google.maps.event.addDomListener(window, 'load', initialize);
			}
	</script>
	<?php echo ob_get_clean();
}