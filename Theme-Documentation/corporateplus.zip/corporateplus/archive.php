<?php
/**
 * The template for displaying archive pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Corporate_Business_WordPress_Theme
 */

global $corporateplus_opt;

get_header();

if(isset($corporateplus_opt)){
	$bloglayout = 'nosidebar';
} else {
	$bloglayout = 'sidebar';
}
if(isset($corporateplus_opt['blog_layout']) && $corporateplus_opt['blog_layout']!=''){
	$bloglayout = $corporateplus_opt['blog_layout'];
}
if(isset($_GET['layout']) && $_GET['layout']!=''){
	$bloglayout = $_GET['layout'];
}
$blogsidebar = 'right';
if(isset($corporateplus_opt['sidebarblog_pos']) && $corporateplus_opt['sidebarblog_pos']!=''){
	$blogsidebar = $corporateplus_opt['sidebarblog_pos'];
}
if(isset($_GET['sidebar']) && $_GET['sidebar']!=''){
	$blogsidebar = $_GET['sidebar'];
}
switch($bloglayout) {
	case 'sidebar':
		$blogclass = 'blog-sidebar';
		$blogcolclass = 9;
		$corporateplus_postthumb = 'corporateplus-category-thumb'; //750x510px
		break;
	case 'fullwidth':
		$blogclass = 'blog-fullwidth';
		$blogcolclass = 12;
		$blogsidebar = 'none';
		$corporateplus_postthumb = 'corporateplus-category-full'; //1144x510px
		break;
	default:
		$blogclass = 'blog-nosidebar';
		$blogcolclass = 12;
		$blogsidebar = 'none';
		$corporateplus_postthumb = 'corporateplus-post-thumb'; //500x500px
} corporateplus_pages_breadcrumb(); ?>

	<div class="section_padding blog_posts padding_bottom">
		<div id="primary" class="content-area">
			<div id="main" class="site-main">	
				<div class="container">
					<div class="row">
						<?php if($blogsidebar=='left') : ?>
							<?php get_sidebar(); ?>
						<?php endif; ?>
						<div class="col-xs-12 <?php echo 'col-md-'.$blogcolclass; ?>">
							<?php
							if ( have_posts() ) : ?>
								<div class="blog-grid-area-inner">
								<?php /* Start the Loop */
								while ( have_posts() ) : the_post();
									/*
									 * Include the Post-Format-specific template for the content.
									 * If you want to override this in a child theme, then include a file
									 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
									 */
									get_template_part( 'template-parts/content', get_post_format() );
								endwhile; ?>
								</div>
								<div class="pagination_area">				
									<?php the_posts_pagination( array(
									'type'      => 'list',
									'prev_text' => __( '<i class="fa fa-angle-left"></i>', 'corporateplus' ),
									'next_text' => __( '<i class="fa fa-angle-right"></i>', 'corporateplus' ),
									'before_page_number' => '<span class="meta-nav screen-reader-text">' . esc_html__( 'Page', 'corporateplus' ) . ' </span>',
									) ); ?>
								</div>
							<?php else :
								get_template_part( 'template-parts/content', 'none' );
							endif; ?>
						</div>
						<?php if( $blogsidebar=='right') : ?>
							<?php get_sidebar(); ?>
						<?php endif; ?>						
					</div>
				</div>	
			</div><!-- #main -->
		</div><!-- #primary -->	
	</div>

<?php
get_footer();